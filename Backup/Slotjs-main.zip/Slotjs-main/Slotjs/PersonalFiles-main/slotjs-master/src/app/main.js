import { App } from './components/app/app.component';

// eslint-disable-next-line no-new
new App();
