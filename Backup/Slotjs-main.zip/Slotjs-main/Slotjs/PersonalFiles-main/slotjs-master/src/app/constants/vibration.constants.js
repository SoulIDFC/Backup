export const VIBRATION_STOP = [200, 50, 50, 50, 50, 25, 25, 25, 25, 25, 25, 25, 25];

export const VIBRATION_START = [25, 25, 25, 25, 25, 25, 25, 25, 50, 50, 50, 50, 50];
