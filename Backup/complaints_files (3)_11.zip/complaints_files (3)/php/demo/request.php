
<!DOCTYPE html>
<html>
<head>
	<title>PayKun Demo</title>
</head>
<body>
<center>   
	<table border="1">

<form method="POST" action="submit">
	<h1>PayKun Demo</h1>
		

	<tr>
		<td><label>full name</label></td>
		<td><input type="text" name="full_name"></td>
	</tr>

	<tr>
		<td><label>product name</label></td>
		<td><input type="text" name="product_name"></td>
	</tr>
	
	<tr>
		<td><label>email</label></td>
		<td><input type="email" name="email"></td>
	</tr>

	<tr>
		<td><label>amount</label></td>
		<td><input type="text" name="amount"></td>
	</tr>

	<tr>
		<td><label>contact No</label></td>
		<td><input type="text" maxlength="10" name="contact"></td>
	</tr>


	<tr>
		<td colspan="2">
	 		<center colspan="2"><input type="submit" value="submit"></center>
		</td>
	</tr>

</form>
</table>
</center>

</body>
</html>
