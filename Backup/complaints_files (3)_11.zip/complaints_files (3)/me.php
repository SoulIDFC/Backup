<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location:login");
    exit;
}
require_once "config.php";
$opt="SELECT SUM(amount) as total FROM `bonus` WHERE usercode='".$_SESSION['usercode']."'";
$optres=$conn->query($opt);
$sum= mysqli_fetch_assoc($optres);
if($sum['total']==""){
    $bonus=0;
    
}else{
    $bonus=round($sum['total'],2);
}

$sql = "SELECT  notice FROM notice WHERE id='1'";
$result = $conn->query($sql);
$row = mysqli_fetch_array($result);
$notice=$row[notice];
$opt1="SELECT SUM(amount) as total FROM `intrest` WHERE username='".$_SESSION['username']."'";
$optres1=$conn->query($opt1);
$sum1= mysqli_fetch_assoc($optres1);
if($sum1['total']==""){
    $bonus1=0;
    
}else{
    $bonus1=round($sum1['total'],2);
}

?>

<html lang="en" style="font-size: 37.5px;">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" 
      content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <link rel="icon" href="WhatsApp_Image_2022-11-30_at_10.45.27_PM-removebg-preview (1).png">
    <title>Red-bul13</title>
    <link href="css/app.46643acf.css" rel="preload" as="style">
    <link href="css/chunk-vendors.cf06751b.css" rel="preload" as="style">
    <link href="js/chunk-vendors.824d6eef.js" rel="preload" as="script">
    <script src="https://code.jquery.com/jquery-3.5.0.js"></script>
    <link href="css/chunk-vendors.cf06751b.css" rel="stylesheet">
    <link href="css/app.46643acf.css" rel="stylesheet">
    <script>
         $(document).ready(function () {
        $("#balancetop").load('balance');
    
        setInterval(function () {
            $("#balancetop").load('balance');
        }, 1000); 
    })
 
   
        </script>
        <style>
                    
.loader-wrapper {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  
  display:flex;
  justify-content: center;
  align-items: center;
}
.flt{
    position: fixed;
    top: 291px;
    right: 19px;
        width: 67px;
    font-size: 17px;
    height: 67px;
    border-color: #009688;
    color: #009688;
    background-color: #fff !important;
    border-radius: 50%;
}
        </style>
        
</head>

<body style="font-size: 36px;"><noscript><strong>We're sorry but default doesn't work properly without JavaScript
            enabled. Please enable it to continue.</strong></noscript>
    <div data-v-1f39f91d="" class="mine">
        <div data-v-1f39f91d=""  class="mine_top">
            <div data-v-1f39f91d=""  class="mine_info" >
                <div data-v-1f39f91d=""  class="mine_info_top">
                    <div data-v-1f39f91d="" class="info_left"><img data-v-1f39f91d="" alt="" class="photo_img"
                            src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMSIgaGVpZ2h0PSIxMDAiIHdpZHRoPSIxMDAiPjxyZWN0IGZpbGw9InJnYigxNjAsMjI0LDIyOSkiIHg9IjAiIHk9IjAiIHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIj48L3JlY3Q+PHRleHQgeD0iNTAiIHk9IjUwIiBmb250LXNpemU9IjUwIiB0ZXh0LWNvcHk9ImZhc3QiIGZpbGw9IiNmZmZmZmYiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHRleHQtcmlnaHRzPSJhZG1pbiIgYWxpZ25tZW50LWJhc2VsaW5lPSJjZW50cmFsIj45PC90ZXh0Pjwvc3ZnPg==">
                        <ul data-v-1f39f91d="">
                            <li data-v-1f39f91d=""  >User：91<?php echo  $_SESSION['username']?></li>
                            <li data-v-1f39f91d=""  >ID：<?php echo  $_SESSION['id']?></li>
                        </ul>
                    </div>
                    <div data-v-1f39f91d="" id="icon" class="info_right">
                        <div data-v-1f39f91d="" class="notice"><img data-v-1f39f91d=""
                                src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACxklEQVRoQ+2ZP2gUQRTGv7dHqjSWahVBicQyB4J/IGkEW0XBzk5stNiZvSNNkibc7pstFATt7ARFLAUbA2pAMKXBoIWVWtqkkOP2ycAdRHOX3dmbu1zCPjgWbt68937zvpvdmyWM0LTWTwBc6aZ4w8x3RpWORhVYKbVMRCu744vIijFmdRQ5RwaitZZ+BddqtVOtVuu7b5ixg4jIojFmvQIZsAJeO6K1vgVgAcB899Mv7R8ieiQiG8z80ldnvIBora8DuA/gsmNh7wA88AE0FEiz2ZzpdDrLAG47Avzv/rRWq60OswmUBtFa3wCQAJgZEqI33e5kETO/KBOvFEgX4nmZhAXm3CwD4wyilFogorcFCirtUmaLdgbRWlsIuzON0taZedElgRNIv8cOl2Quvq6PM4VBlpaWTrTb7U8ATroUNITvj6mpqfra2trPIjEKg4yzG73CXbriAvKViE4XWR1fPiLyzRhzpki8QiCNRuNClmUfigT07RMEwcU4jjfy4hYCOQhZucpr4kEAPGbmu4e+IwBeMfO1owBS6OZ4GKRVgeyR40HuWgCqjlQdydsiS45X0qqkVVI6edMqaVXSytNIyfFKWpW0Skonb1p5aSmlzgNYJSJ7PZaXaUzjv0XkI4BlY4y9/mN9/49ore35lX3HMYm2ycz1XJAwDOeCIPg8iQS9mrIsO5em6dbuGvd0JIqiWRH5MskgRHQ2SZLtfUHs4JGQlgUJw/AqET0c98lingrsyaOI3EvT9HXub6TnoJSaFpE5IprOSzCOcRHZIaItY8xOv3yFTlHGUeiwOSqQQSuolHpGRMf3W2ER+WWMse/kvZn3jkRRpEXEvu0daEQUJUnC3igAeAcJw3A+CAL7ZDDQsiyrp2m6OdEg3fuQAjBoxTUzG58QNpb3jvQKbDQal7IsawGY7X63HQRBM47j974hbLy/futAQjLys7MAAAAASUVORK5CYII="
                                alt=""></div>
                    </div>
                </div>
                <div data-v-1f39f91d=""  class="mine_top_items">
                    <div data-v-1f39f91d="" class="top_item">
                        <div data-v-1f39f91d="" >₹ <div  style="display: inline; " id = "balancetop"> </div></div>
                        Balance
                        <button data-v-1f39f91d="" onclick="window.location.href='/recharge';"class="one_btn ripple" style="" >
                           Recharge
                        </button>
                    </div>
                    <div data-v-1f39f91d=""  class="top_item">
                        <div data-v-1f39f91d="" >₹ <?php echo $bonus?></div>
                        Commission
                       <button data-v-1f39f91d=""  onclick="window.location.href='/bonus';" class="one_btn ripple"style=" "> see</button>
                    </div>
                    <div data-v-1f39f91d=""  class="top_item">
                    <div data-v-1f39f91d=""  >₹ <?php echo $bonus1?></div>
                        Interest
                        <button data-v-1f39f91d="" onclick="window.location.href='/intrestrec';"   class="one_btn ripple"style="">See</button>
                    </div>
                </div>
            </div>
        </div>
        <div data-v-1f39f91d="" class="mine_nav">
            <ul data-v-1f39f91d="">
            <li data-v-1f39f91d="" style="display:none;">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACOUlEQVRoQ+2aMWzTQBSG3ztLWVmpGJEYysgEU9lZGGAqEy4LEgO+mzK0LEl0d6aDJQZEp26txEA3pkx0YiwbEkOlVurUsiRD7qFUDG1yjRv71bGry5z3v/97/50vtoNwSz54SzgggNQtyZBI4xJRSt0djUZLQog7izDvnDuNoujIGHM8q/+VSytJkkdCCAsAK4sA8PTsO+dkmqY/fX68IFLKx4j4oyYAl2wQ0RNr7f6kNy+IUmoHAF7UEQQAdo0xL3NBkiRZFkIc1BTi3JZz7mGapr8uepxKREr5GhG/1BmEiGJr7VYeyDoibtQcZMNa+yGA1CUlIgqJ1CWMcx+siYzFWq3W506nc8RFqZR6Q0QJIj6YpckG4hNihHkGAHtVgTy11va5zE/qKKWoKpCpqwYXlJTyOSJ+rQRk3AQRV6Mo+t7tdk84INrt9r3hcBgj4isAuF8ZCIf5ohpsm72oAa66AMI1SS4d1kTCgZgTi1IqHIiXZiSlzL2xusmfKIs4ED8KIbJer/eHYxOHA/H/FH0PH3KXFkcCZTRYL79ljJStDSBlJ8hdHxLhnmhZPSKaukNt4lXrEBGXtdZ/Lw6kiSDvjTGbk6k2DSQzxrzzLc0mgBwCwD4i7mmtt6/aX/OCnCBirLX+VnbDctfPA3JARGu+117cporoXRdk/DAuNsb8LtKkiprrgOwOBoM4y7KzKgwV7TEThIg+WWvfFhWvss4HsoKI60TUn3y9VaWxeXuF/6LMO7Gb/v4/Av6hQgwN1SIAAAAASUVORK5CYII="
                            alt=""><span data-v-1f39f91d=""onclick="window.location.href='https://t.me/TcsClubsofficialchannel'"> Prediction Group</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li>
 <li data-v-1f39f91d=""><ol data-v-1f39f91d="" id="signin"><img data-v-1f39f91d="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAADi0lEQVRoQ+2Zu2sUURTGvzvDCho1+AIRwYCgEAVFwRcWiqBoISjERgULiRiwSGbObMTCtVkkZ7YKilHQJiZiwDpioYWiFtFKwb9AFLELxGaOXJkJm81M9mYeyxoy5dw73zm/+93nXIUl8qglwoFlkHZzMpUj/f39623bviEi92q12q+8oFzXvZ1WMxUIEX0GsBfAF2benQcIEY0CuJhWMy2IRMkzcyqNRngiyqQZm0S5XO4UkYqIHAtbPo9Gz6rxEcDbUqnE1Wr1R6PYPJByuXwkCIJ3WaMW+X0QBLtqtdrX+hhzQPr6+lZ3dHR8A7ClyERy0P4yMzOzf3h4+E+kNQeEiK4AeBIW/haRZwAm5tmo1OvonYgczyExqCaaSqkDInJLKbVWx1NKXR8aGnqQBPIIwNWw8CkzX4pLkoh+AtgE4Dczb8gDxETTdd1JpdSpMN4oM19OAtEtrQc49GD3ff9OXJKe550XEb2OjPi+r13L/AwMDOywbXtkIU29ziilKmGwN8w82xsau5YRSOasUwosgyR1rZQNmvmz1I5kjlyAwKLHSAE55C1pNtjzjlqAnhmInn4LCJ5ZctFda6F1JHM2KQVSD/ZWz1qu6x7zff9NEmfbg/T09NhdXV3jAHoAfGTmQ3EwbQ1SqVRWTE9P623OuSj5uG26LmtbkN7e3lWdnZ3aibN1Dkww84X/xhHP89aEx4QzJhBt6cjg4OC6IAjGRSTakus8E52IQHPvWkQ0AqA3zRTtOM5Gy7L0mDhh6kQhIHqKbDjNJZ5bGvs5EW0GoMfEvzNP+DR1ohAQLUpEHwAcjAKYOON53lbdnZRSR9NAFDJGHMfptizrOYBdJjCO42yzLEs7cTgtRCEgWtQUhoi2AxgDcCALRGEgJjDhOVw7sS8rRKEgC8GIyIRt22MisicPiMJBkmD0z+j6MWSyTsSt5vXvcl9H4gLGjZm8nChs+k1quQQY43WiLRyJkghhHgPYCeBV0gawWdJx5S3pWmkSW+w3yyCtPuo2c8jYEc/zbopINRTUN0R9zPypWYBWlIeL64u6Kf0uM9+MYjf+xD4J4GVdYvoi5X0rEjWIoTepK+vqnWbmyVgQ/ZKINPXs+dkgQMurxO22Yy9Dieg6gPstz9As4ENmvtZYNfFqWZ8fROSwiHSb6RdbSyk1VSqVpqrV6ve4SLnckReLYKa+DGLWTq2rtWQc+Qu79LFRZ28khgAAAABJRU5ErkJggg==" alt=""><span data-v-1f39f91d="">Sign In</span></ol><ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down"><!----></i></ol></li>
                <a href="bets"><li data-v-1f39f91d="">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAB6ElEQVRoQ+2asUoDQRCGZyBPYKeV1r6EPoKgQsBGIYKN1Y1CGrU7bg4uYGvAxiCm8Q2Sh7ASCytLsRNygZGDPTkuF3PLJZtzs6nCMMPONzP7J3t7CJZ80BIOcCB16+TMjniet1OHpMMwHP6Vx1QQIroAgDMA2KwDiIi8AkAvDMObonwKQYioCwAndQAoyOGQmft5+wRIu91ej+P4o6YQSVrvzLw1EyTZE4g4SB1F5LoOUIj4m4eI7Ob3zERHikCmzaUpQM/zrhxIdrRcR+Y0e2608qpVNFqqSqcAMBiPx60oir6TBmTsG7oNEZFuo9Hwfd9/y8YutCNE9AIA22rBO2ZuJd9zdl2WxP+cmW9NgvQAoKkWPGbmewWStWuDIOJeEATPJkGaIrKPiMNsBYkota/pUiBifzQa9TqdzpcxEN0kq/gvdI9USUw31oGUkV/dqlbxdx0p05GMOs1VteI4foyi6NOYahHREwAcqAUvmTlQvyNZu/ZEIeJREAQPDiStQNmDlTWjpT0zFQKcapVRrQoF1g51HVmpjixKtYz/jSciaw5Wdhx1rXn4oK2hFQKc/K6U/FaYFO1QN1pWXPRYc/Wmjqv//zI03YlWXE/nDv7/+4UBbY1ccsDMVziWnF/p5R1I6VIZcvwBChr8Ue16BMAAAAAASUVORK5CYII="
                            alt=""><span data-v-1f39f91d="">Orders</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li></a>
                <a href="invite"><li data-v-1f39f91d="">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAEMUlEQVRoQ+1ZXYgbVRT+zoSQpVtFfBHqCorgikJRXwoVoT4o+tBiH1pBfLD+IasRJfeMsBQ2FczuzpndQAsLSpGCCGJfSvdBqEIXEX/oi/qgtqC0FFZELIKLP2ySU6ZNlsnsJDOTmYm65EIecu/5+b57ztxz7gxhiwzaIjwwIvJfi2TqiDDznaq6E4D3AxFdFpF3+xFl5mdV9ba2/LlCofDd3NzcxTSbMzCRqamp7ePj4wLgpRAApwAcEZGv/WvMfB+AGQBPhOgsNxqNZ+r1+pVBCA1EpFKp3G1Z1vcRDn8H8KKInPTkmPkAgHcA3NRPr1gs7qjVaj8nJTMQEWb+AcBkHGeq+nA7hc7GkQewIiLXdJKMxESMMTNEVA1xsgJgT495b7rX2qZ5Va26rnskVyLM/CEAL002RrPZnFxcXLxgjNlFRF/GARChsywi++LY6cgkjggzXwYw4XPiiMgbnf+2bVdU1Y0AEaWzKiK35krEGHOeiO7qOAmmQZ/U28AVQ+eiiNyRKxHbtuuq+lrAySEROdE+mbzUizP66ZwQkUNxjPRNLWPMHiJ6HsDjAG5OYjBH2V9V9bRlWWcdx3k/6GfTM8LMpwHszRFQFqY3RayLSJJTJws0KW3c7+8cuogw8+sAFlM66FInok9V9W8Aj2ZpN3hgBIl41ddfoFZU1St0sUZIofwJwIOtVqthWdZnwW7AAxPL8PVm1MPVhc3fAUQSidMu2LY9oapfAdjhA/YPEe11HOdjb46ZHwJwBsCYT+ZSsVjcVavVfokixMybNjlzIsz8EYDH/GBardbLCwsLS/45Zi4DOBoAfVJEDv7rRJh5HoAdAHJcRF4IA8fMHwB4MrDGItK3G8g1IsaYp4noPT8oIrpQKBR2z87O/hZGZHp6+pb19fVzAK5drDpDVfe5rrvcKzK5ETHG7CQir4p3tfOq+ojrup/0S5UeHcC3RHTQcZzzPSKZzzMS1gWr6mHXdd+Kyndv3RhzjIheifu85BaRNpinALxNRNsBfCEiu+OQ6Mgw8zftu75XZ2ZExBl6avnAPEBEbzabTe+UupSEiG3bk6p6lIjmHMfpe4PMNSId0NVqdVu1Wv0zCYmOrG3bNziO80eU7lCIRIHIYn1EpL2LA73RyCICQRupI5KkacyDQMdm2qYxT2xpbXdlS1T3m9ZZnvojInnu7iC2RxEZZNfy1EkUka1TR+Lc2fPcdl9zms99ZBjg/T5SV/b/a0SC3z5iv9MaUoT877VOicj+jRbGD8AY8xwRHR8SqLRuXhWRY6FEyuXyjWNjY6sAxtN6yVn/SqPRmKjX63+FEvEmK5XKPZZleSl2b85gBjW/alnWgfn5+c/9BkI/vZXL5VKpVNpPRLeramlQj1nqWZblXaV/XFtbO7O0tLQWtJ34G2KW4LK0NSKS5W5mYWvLROQqDqopUSkA7bQAAAAASUVORK5CYII="
                            alt=""><span data-v-1f39f91d="">Promotion</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li></a>
                  <a href="red">
       <li data-v-1f39f91d=""><ol data-v-1f39f91d=""><img data-v-1f39f91d="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFEmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMC0wNy0yM1QxNDozMTozNSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDctMjhUMTM6MzE6MjErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDctMjhUMTM6MzE6MjErMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzNmNGMxMGQtYmI1OS0xYTRkLTk2ZjgtM2U1MTUxMzM3YTlmIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjczZjRjMTBkLWJiNTktMWE0ZC05NmY4LTNlNTE1MTMzN2E5ZiIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjczZjRjMTBkLWJiNTktMWE0ZC05NmY4LTNlNTE1MTMzN2E5ZiI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NzNmNGMxMGQtYmI1OS0xYTRkLTk2ZjgtM2U1MTUxMzM3YTlmIiBzdEV2dDp3aGVuPSIyMDIwLTA3LTIzVDE0OjMxOjM1KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PpeylawAAAaVSURBVGiBvZprbFvlGcd/z7F97JCEtlnDQkIvi2giNnGNUGGMUW0QBBtFAcQgTEPdxto4DSIUSM34kA+odYpQt7QxpKISUNFdWgaVgHbTKIVxK2ydpq4ZLQWqtF0bmrq4xLHjy3n3wUl37NqJzzlO/1LkvM953+f//P3en2NRSjEBEaFk6Ovxo6lmNB5k6crB0jn+P8yxu6eDgGfXLEAZT6PwYVAB3DgtPCZo0+JVqVYUvsz//JBnelZMC48J0yWkJatsqC761144LVzjKP3QCvUsBnV5lk2oJhV/AminPzgDg1YMdT1IE0IDyAb8XUud0NoTEgq+BTQBA4hsR2Qzyx77NBO0ehKVp42In77gjaRpGC+bHqoGW3GY3dtatULBo0BtjnUXiu8gVFuOwjB+xPLH37DazBy73TmyN49tkS0RIt12ROTCnhBRa5wSj+O/aPqGUjiyJ6QtsBPhFcfsIhtY2nnMsR+cLL9KAiCHHXCXrDfAiRB/136EgAPuf5SqN8DphtjW9RLwG5uthx1x58D5zl4WDwDvWm+ojjvmNsG5kCXdcVC9FlsdR7Qxx9wm2NsQ8yEUXAssAq4wWUdBnQQZBo4AH6G0j5D0x/gDp+yTZZAV+7TdR84BSnsfCQV7ERYBm9HYPOUlqq+7AnyXIfJjlNGCyCeMxZfQ2f2VkzCc9Ugo+GegOcf6LiJ/PauuUvXApeN/2V+gsBeRTpZ1vWmFvjRDqy94HOGbVoinQAqRFbR1Fb1wOBPS230+bl/EWowWIPSjfd7B0g3JqaraF9LbcxFu5eRYUhyUegPd+DkP/Hpo8mp2hPT1XIKoAedRFo0DaEYLyx4vyGn9PrJ+1cJzLAKgAUPbR1/we8VUnlrI+lUL0bQPHYdlF8LfCPU8NGW1SYdWf3AuKT5Dpin/ZQ0P4l+5zmwobo78sVvnhO8dhIWW6JQBYzEwJqkjbvB5M+MhX6KisPO78Qe2nCkVJSQUfAp4xAoNSkHaYG7NPObrhReOcleK3UNDhGMpcFk6t36OpL5P2xNHM3RTHVHWrV6EVRFkRMxv/AFfNF8zedXIHhq3HCJsuMFliaQe3Mvh7Atd/h4JBXcAN1uiQIES5sy7jPuqdEaTSdxllXz3W03cOdsHpHnv0B42fRFm/5EBdp38Grw+LI4tgBE090KWPTIw+dAKrboftOetej+DWARiCTAM0L0wq46WG1r4U+OFDPx7O5dveo1UTR2UeTPzyRbUs/gDbVMIWb0NZLEt/+k0FVX1bGxezE2VLpQyiCVixDwVXFymA5CIjzIU3stNf9nJ/ogC3drYGkcEXa9Xv+gMTxiyZ1p/8FLbIlAgGhfVLaDBnSA8FmM4HuXYaJRIavybN9J8HRvlzYOfMXh6DDy2RADMIJm8xWzInuyG3GFjzI5DwAWf/OtlrnxrJLP8emdSVltH63W381xlDeHDH3DVC9sYnDULPOdhnwuAVuCliULOqqXmO/FMWnFeeRO/uvYCZqaFGeXV3NzYyCU6wFc8vfefDM6YBW4XDkWAUreai9lClCywT6AgpTjfdyVrr6432dN8emSA3/79AzYeCoOvLLPfFISBnZxIbotGyx7OQMBlMBzfTf/wRIJkhP6dW7nu5a30HTxKXPcVIaLGFnuOEFVuy8sEXC5S0QN07niVTZEUUMFPrmji1uqqzPMp720G8G1b1LlCwvmrFQsBj5fY0D4e2LaFzSNJZlZdzPO330XH3GoYiYI2mRoBThRLlpVOyhGinbQSdsFgyssZ+3IfS7Zu4fenk1BeR+9td9ExZzZEoqAVmgMuYE+xPFkJjhL3yIQboLKSxPAAP3t1K787lYSyGnpbWlk+5xtweiTn1ZsZ3mJJ3jaXsoWIPGc96gIwgIpKkif+w/2vv8KLw2Pgnc26O++lY94FMBpz5l/k46xi1hFl49oqEolDQKUzFjMUJJK4K6uo1TV8Hp34aITB6JjVI7wZu/GvvKbwnf2XD4cR9YL9oPNBQPeQip5iMDzMgaFjDMYS4HaQPxdZl2s625uhr4FSp3wE3B7w6ODxZOaH/Y19+/h7mSycLaR9xWGUVqqXnaXGCIon8z3I37/tXetR6h6ESRNk5xxpdRvtK9/P96jwQG0P/AGVbgYp2QtLB9iPx1VPR2BXoQrFZRpDq5tAfgpcT+anG+cKB4HtRF0BHn00mvvQWRK7v3s2Ke9ViFaHohaNWgxVh1CLIvNpD6eA48AQig9BvU17YMdkDcyx/w8HL3OqkQG2xwAAAABJRU5ErkJggg==" alt=""><span data-v-1f39f91d="">Red Envelope</span></ol><ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down"><!----></i></ol></li></a>
                
             

                <li data-v-1f39f91d="" id="wallet" >
                    <div data-v-1f39f91d="" class="van-collapse van-hairline--top-bottom">
                        <div data-v-1f39f91d="" class="van-collapse-item">
                            <div role="button" tabindex="0" aria-expanded="false"
                                class="van-cell van-cell--clickable van-collapse-item__title">
                                <div  class="van-cell__title"><img data-v-1f39f91d=""
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACfElEQVRoQ+2av4vUQBTHv29hS8EflYjddTbC2Vh5lorbCAqizaF/gEomgs3dtftmtUgpiJUIFhZ6tVtcYSGChVrZXCHaWAjCLgvzJOLCbnayySSTmLtN2sx77/t572UyMwnhkFx0SDjQgjStkqtREaXUWRE5+j+zPx6PP0RR9CtLg7UiYRhuGmMeEtFaloOa7r8GcI+Zv6bFWwBRSr0FsFGTQKcwxpgzg8Hgs81oDiQIgi0i2nbyXu/gT6PRaD2KonEy7ByIUuoJgDv1anOOtmZrsSRIY9tqiisiF7XWw6yKtCALGSL6ISL7AH47N88SAxHZqbMiPWZ+4xMgy5f3Z2TZFJklpsx9ryAisq213ikjqKitb5AbWusXRcWUsfMNMjc1BkGwQURbZQSm2YrIcLb6dYDEU7r3K9nGLYgtxcm37r/WaiuyrB/b1srztBZord5kMtnrdrsnROSWyxaiMRWxrQCUUlcAxLvBzKspIM+YedOmNgiCfSI6nUXSFJA+Mz+wiVVKvQewflBAXjHz1RSQnwCOHRSQWOd1Zn45K9jlzKAprfVXfyym0+l8BHBERHoArmVVYnq/USB5RaesIua2DO1aq11rlemnGdv2GcmTSNtaC8CFPLZFxlS2QwRwm5mfFhFV1sbrrAXgOTPfLCuqiL1vEOsbu4gwV5sqQKZv7F1jzBettdcj0zTASkBcs+kyfuVO43cBXHbJUN1jieh8v99/l4ybbK1H8UfHusU5xjvJzN+zQHLvmR2D+xr+mJnv25wtfNV12dz4UpfTzzdmPpVr1poOCsPwnIjcBXAJwPGcgaoaNkweWOeqSFVqqva7Gv+iVJ1Fn/7/AEvxCVHd7ZIcAAAAAElFTkSuQmCC"
                                        alt="">
                                    <div data-v-1f39f91d="" class="nav_name">Wallet</div>
                                </div><i class="van-icon van-icon-arrow van-cell__right-icon">
                                    <!---->
                                </i>
                            </div>
                            <div class="van-collapse-item__wrapper" id="walletdrop" style="display:none;">
                <div class="van-collapse-item__content">
                   <a href="/recharge"> <div data-v-1f39f91d="" class="nav_content">Recharge</div></a>
                   <a href="/withdraw"><div data-v-1f39f91d="" class="nav_content">Withdrawal</div></a>
                   <a href="/trans"><div data-v-1f39f91d="" class="nav_content">Transactions</div></a>
                </div>
            </div>
                        </div>
                    </div>
                </li>
                <a href="/bank"><li data-v-1f39f91d="">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABaElEQVRoQ+1ZO07DQBCdOQhSLkEfLkCfjgopBZ1HchnqWblIBRWpcgFaJLhIquQYlidyFEfGARPLO/aymW29fm/fvNnfLEIkDSPRASYkNCfNEXNEKQI/plaappM8zydKnL1gi6LYZFm2bYKcCSGiJQA89WLT//mdme/rNN+EENEjALzqj6M/g4gsnHPPFVJTyBsAPBw/fvWnU0GYHlF3zHzzm5BPADh0FJE751xQYpIkmSJiOcZDY+aTEU1HTIhKEjVAr96RxRBR7sqBiKdxXTRHuhKM0d+EjBH1Nk5z5L86EtSuXgtidUSxnX30zLr6nd1Ov1o5aKmlfbEiojUi3rY5KCIfzDwv+wTrSCkEAGZ/pOKLCRnqzm6OhFZ8iMmRqobWOt+ZeRX0qtV14wx2+TUhoU12TUfqReyuPEP3by1ix/GsUIY0ioeeKjeieHobOtF98dk7u69I+sIxR3xF0heOOeIrkr5w9v4wfUJPH/TeAAAAAElFTkSuQmCC"
                            alt=""><span data-v-1f39f91d="">Bank Card</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li></a>
                
                    <a href="/address"><li data-v-1f39f91d="">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAADGElEQVRoQ+2aPWgUQRTH/28TsDGFQiqbxI9CAxYqRGxMGiFga6WFwY9A1GpnwqUQY5WQma3UgF+YQhtrIWBjbMSACgpqoeI1VgGb2EiSeTLqhctm9tydu13ucKedNx+/+b95M/N2CS0qUsrbAE4A6EvZZRXAU6XUWEr7hmbUik6EENeIaMqnL2ae0lpf92lb36ZpkEql0re+vv61mYl0dXX1z8zMWIW8S9MgQoghInrmPQMAzDystV5spo8SpLZ6CYqMKaXuuFZYSnkRgA0MG6VdFfmilNrbyE2klJ8B7KnZtCuI9fmjWuslF4wQYpCIXnaCIrU5Jm3eoThg2yqSNfqUIHUrVobff4TfTN7Vzq4VMfMTFw0RnQQQdkLUWu7u7h6Ynp5edoFMTk72rq2tvQfQ29bnCDN/C4Jg/+zs7IoLZGJioscY85GIduUOUqlUdqyuru4mop40zu64ND5k5vsJrnUOwJncXauZt0UaaJdNyze7lPIUgMe+E/JtlweIhbAwhZY8QOwDactdKG+qEiTpiiKldCnyHcACM3+KK0NE+wCMANgZq1ti5oWEqGXtB3ONWi4QZp7TWl9Kci8hxC0iGq+r/wngmFLqjauNlPIQgBcAtuV2jiQoMqqUmk8CkVKeBfCgrr6qlOpvtK+klDbrspH/KmqPVJnZgjx3TO44EVmQeFLuETPfS3Ct8wBOewaQFSJ6a4y5Gs+6bLrGJyjiOWa+zYwxA1EUfaiN0rEg9gqktbbq/i4dCwJgUSk1XILk6/mZev9/Fcn9ZAfgM0Y2RQo62bPeHqwPZgMBkPvJ7jGGF0gRJ7vPGJkVyRRKCjQuQQpc7FRDlYqkWqYCjQpTJPWHHk/4/EGMMUeiKHrtmmAYhoeDIHjlOfn6ZrmDbBog4d3eirRTCZLWG0pF0q7UX7tk1xJC3CCiyxk7jJsXoggz39RaX3E+dVvxgwyAeaXUaKPFkFLaPJhNI3mXeC5sy1fdMAwPENHdIAgOMvP2jCNVjTHjURQ506W1vsIwHAmCYC7DT2p/MiVEP4wx75j5Qn0qyNb9AvxLOVFLLAVxAAAAAElFTkSuQmCC"
                            alt=""><span data-v-1f39f91d="">Address</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li></a>
               
                <a href="/security"><li data-v-1f39f91d="">
                    <div data-v-1f39f91d="" class="van-collapse van-hairline--top-bottom">
                        <div data-v-1f39f91d="" class="van-collapse-item">
                            <div role="button" tabindex="0" aria-expanded="false"
                                class="van-cell van-cell--clickable van-collapse-item__title">
                                <div class="van-cell__title"><img data-v-1f39f91d=""
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAEbUlEQVRoQ+2aTWgkVRDH/0UCzuYQvehF1IN68QuRXUFcP+NBXBe/RfADQQ0GjOsk7z0UD44g6HS9STJMZDWrB9GDqCuKJnhZ8WPFg4u4rnpZ9+B6cz1oDmGEJCUvdEtn7On3umeUEOYd86rqX79XXd013SFsk0XbhAMDkJBKKqXuI6J9zlZEmtbat0P8ytj0vSLj4+Mjo6Oj+4joKQBndST1m4jMLS8vNxcWFlbKJNzNp28g09PTF7nkieixkARF5ICDajQaP4XY+2x6BlFK7SGiKoAxn1iX/UMiMmutXSzpv+FWGkQp9QQRaQDnehJYAnBLQJInRYSttfMBtv8yKQQyNTV1ztDQ0DSAjQbOW0R0gIhertfrR7XW4rPv2G+ura01ZmZmfg31CwLRWl8HwASc7O8iMr+6utqcm5v7I0miBEji6qoZMfPnPqBcEK31ozHAhXmBROQoEc0z82tZdj2AJOGOx0CZ8XN7JFB8SUQa1tpP80ADY/kOfWOfmTMPv2tFPOL719fX641G45cQ9a0GcoqI6lEUNUKST9tsKRARucFa+1lRCGc/AMk4tZ57ZFCRwaWV3Y2DSys5l0GPDHpk0CObT0Br7cbw07dYj/zJzGdk1SpvaHQD4T+//kSkVmY86dWHiNK6J5n5vKIg3wO4tNdE8kZvX2xjzP0i8lbK7hgzX1YIRCn1JRHt9omF7Hd7iPl8lVLPpSsiIoettdcUBdkUxCeat18WRGv9PoA7Un1as9Y+XwjEGLNTRL7pBSDxLQOitT4fwDEAO5I4RLQriqIjhUDi3xE/ALi4V5gyIEqpZ4nohZT2j8x8SbdcfC8f5kJe/fhAy4BorV010ok3mdm9hs1cPpCrARz2JerbLwqitX4IwBsdcXcz81elQOLL6wMAt/mS7Weza60PAbgxFfNDZr49T8P7gk5rfQ+Ad/4vEGPMnSJysEPvXmZ+tyeQuCru7rWzLEzopaWUcg+7JSI6O6V1hJl3+bS9FYlBbgXwkS9Yt/0QkGq1umN4eNi9Ir2+I85eZv7Ypx0EEsO8COBpX8Cs/RAQrfWrAMY7/F9i5mdCNINBarXa8MrKivuWcW1I4LSND6RzFHG+RPTFyMjIWK1WWw3RCwZxwZRSVwH4hIhGQ4InNnkgxphZEdn0fBCRZQA3W2u/DtUpBBLDPEBEb4YKOLtuIFprdzd0d8VNS0QetNamp16vXGGQGMZ9K5z1Ro8NOkGUUjcBeJKI9mZAVK21bqIotEqBOAVjzOMisj9ELQExxlwpIhMAHs7yI6KJKIpeCYnZaVMaxAXSWl8O4D0AblLtukSkSkRuOui8tSY+JwDczczflYFwPj2BuACTk5NnVioVV5m7SiZxsN1uT7RarVMl/TfcegZJxJVS7ibgPlNfEZjQt/Fn6UJN3S1230Di6pxWqVSqIvIIEV2QJSoiPxPR6+12e7bVav0VCO016ytIWs0YMyYi7p8J9ri/i8giES1GUeQm276v/wyk75l6Am4bkL8BJdARUQFzPqAAAAAASUVORK5CYII="
                                        alt="">
                                    <div data-v-1f39f91d="" class="nav_name">Account Security</div>
                                </div><i class="van-icon van-icon-arrow van-cell__right-icon">
                                    <!---->
                                </i>
                            </div>
                        </div>
                    </div>
                </li></a>
                <a  target="_self" href="Red-Bu13.apk"
                    download="Red-Bu13.apk" >
                <li data-v-1f39f91d="">
                    <div data-v-1f39f91d="" class="van-collapse van-hairline--top-bottom">
                        <div data-v-1f39f91d="" class="van-collapse-item">
                            <div role="button" tabindex="0" aria-expanded="false"
                                class="van-cell van-cell--clickable van-collapse-item__title">
                                <div class="van-cell__title"><img data-v-1f39f91d=""
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAABYklEQVRoQ+3a3RGCMAwA4HQJh9AldAmf6SSek5Rnl9AldAiXqJcT7zi1JW0S4CC8eRd+voQWGnSwkM0txAEG6VfSe3/lVDaEcODsj/uKVKSD7Csv5maQXuasIn/GiN1aNkZsjCTmV5t+34mx50j/BrHniD1HficMGyOkMeK938YYN5Q3WufcCQCqX1FijGfieZ4hhMe/2OxgRwwAXABgRzmRYswdAI4pBGk9MgPMIIIEwaAJMSQEGTIRhowogoyMKUIUQ0bCFCOqIMqYKkQ1RAlTjWBBhDEsBBsihGEjRCBMjAhCDFKJEUOIQgoxoghxCBEjjlCBDGBUEGqQBEYNoQr5wuDP7HoCAzibSBcldwHdEgByiyIO4LOvOkTiIinHMAglS2PGrKMiTdNgm2c2W9u2ybbRUDsIPzvX9qukE5DtSBpEOt2E41lFsDHH+msGIctFIbmvv+uYfovSNXHwYiryAhi53DPcFIGeAAAAAElFTkSuQmCC"
                                        alt="">
                                    <div data-v-1f39f91d="" class="nav_name">App Download</div>
                                </div><i class="van-icon van-icon-arrow van-cell__right-icon">
                                    <!---->
                                </i>
                            </div>
                        </div>
                    </div>
                </li></a>
              
                 <li data-v-1f39f91d="">
                    <ol data-v-1f39f91d=""><img data-v-1f39f91d=""
                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACOUlEQVRoQ+2aMWzTQBSG3ztLWVmpGJEYysgEU9lZGGAqEy4LEgO+mzK0LEl0d6aDJQZEp26txEA3pkx0YiwbEkOlVurUsiRD7qFUDG1yjRv71bGry5z3v/97/50vtoNwSz54SzgggNQtyZBI4xJRSt0djUZLQog7izDvnDuNoujIGHM8q/+VSytJkkdCCAsAK4sA8PTsO+dkmqY/fX68IFLKx4j4oyYAl2wQ0RNr7f6kNy+IUmoHAF7UEQQAdo0xL3NBkiRZFkIc1BTi3JZz7mGapr8uepxKREr5GhG/1BmEiGJr7VYeyDoibtQcZMNa+yGA1CUlIgqJ1CWMcx+siYzFWq3W506nc8RFqZR6Q0QJIj6YpckG4hNihHkGAHtVgTy11va5zE/qKKWoKpCpqwYXlJTyOSJ+rQRk3AQRV6Mo+t7tdk84INrt9r3hcBgj4isAuF8ZCIf5ohpsm72oAa66AMI1SS4d1kTCgZgTi1IqHIiXZiSlzL2xusmfKIs4ED8KIbJer/eHYxOHA/H/FH0PH3KXFkcCZTRYL79ljJStDSBlJ8hdHxLhnmhZPSKaukNt4lXrEBGXtdZ/Lw6kiSDvjTGbk6k2DSQzxrzzLc0mgBwCwD4i7mmtt6/aX/OCnCBirLX+VnbDctfPA3JARGu+117cporoXRdk/DAuNsb8LtKkiprrgOwOBoM4y7KzKgwV7TEThIg+WWvfFhWvss4HsoKI60TUn3y9VaWxeXuF/6LMO7Gb/v4/Av6hQgwN1SIAAAAASUVORK5CYII="
                            alt=""><span data-v-1f39f91d=""onclick="window.location.href='complaints'">Complaints &amp; Suggestions</span></ol>
                    <ol data-v-1f39f91d=""><i data-v-1f39f91d="" class="van-icon van-icon-arrow-down">
                            <!---->
                        </i></ol>
                </li>
               <a href="about"> <li data-v-1f39f91d="">
                    <div data-v-1f39f91d="" class="van-collapse van-hairline--top-bottom">
                        <div data-v-1f39f91d="" class="van-collapse-item">
                            <div role="button" tabindex="0" aria-expanded="false"
                                class="van-cell van-cell--clickable van-collapse-item__title">
                                <div class="van-cell__title"><img data-v-1f39f91d=""
                                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAACNUlEQVRoQ+2aMYgaQRSG33PLtUqZwkauCimEFOelyRXCtaYISJokpUUOwdXS2OnOgFwK26RJhFjYBixyzcVrDuGOdCeIhDSBVG4T0HfswnGnt+uuG28yIzP17Lz/+9//BhlE2JKFW8IBGkS2TuqOKNeRUqn0wDCMA0R8DAC7ggFOiehiNpt9bbVaf1bVXhmtSqXykohsAHgoGGC53C9ErNi2/SlIRyBItVrdm8/nJ/8ZYKF8IpF42mw2v/tp8gUpFotJ0zRPAeCRTCAA8MNxnN12uz1d1uULYlnWKwD4IBnEtZzXjLGPkUDK5fIRIr6VEYSI3nPODyOBWJb1DQCeyQgCAMeMsX3hIOl02qs5Go025Yt4kHw+D9ls1gMYDAbQ6/U2ASMepFargWmannjHcaBer6sJUigUIJPJeOKHwyF0Oh01QVzVuVzOE9/v9zcB4Z4hPlqbUr50jgaJZaw75MlkcuHb6XTqDf0/LrEdcUHcW+v2cm8tDXLjiO5IrEjraIXbpqMV7pHPDh2tcNt0tMI90tGK5ZH4aKVSqQWlk8lEvZ8osbyO9pHYjkTTFGuXBoll2319RETvOOd3XjGCnkylfaAjouec8zvvSqqBnDHGnvh1WykQwzB2Go3GpcogfUR8Y9v2z6DZW7cjx/c1xH7nEtE5Ig7H4/Hnbrf7d1XtdUC6jLEXIkHWqRUVRGoIFzgKiPQQUUCUgAgD+S3zTCzPT1C0vqgEEdiRdW4LWfZuzZ9qrgC4511CCe5B/QAAAABJRU5ErkJggg=="
                                        alt="">
                                    <div data-v-1f39f91d="" class="nav_name">About</div>
                                </div><i class="van-icon van-icon-arrow van-cell__right-icon">
                                    <!---->
                                </i>
                            </div>
                        </div>
                    </div>
                </li></a>
            </ul>
        </div>
        <div data-v-1f39f91d="" class="goout_box"><button data-v-1f39f91d="" id ="outbtn" class="ripplegrey">Logout</button></div>
        
        	<div data-v-405e9a63="" data-v-4af9315c="" class="footer">
        	    <button type="button" class="flt" target="_blank" onclick="window.location.href='https://t.me/red_bu13_official_parity_colour';">
    <!--<i style="color:#27dfd7;" class="fa fa-headphones" ></i>-->
    <img style="width:81%;" src="headphone.png">
    <p style="font-size: 12px; margin-top: -4px;">Online</p>
    
  </button> 
	<ul data-v-405e9a63="" class="nav_foot">
				<li data-v-405e9a63="" onclick="window.location.href='indexlogin'"  class=""><img data-v-405e9a63=""
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFEmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMC0wNy0wNlQxMToxOTozOCswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDctMDZUMTE6MzE6NDErMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDctMDZUMTE6MzE6NDErMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NmY2M2YzNjUtMzkyZS1mMzRjLWE3NmMtODRhMThmZWJiNDJlIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjZmNjNmMzY1LTM5MmUtZjM0Yy1hNzZjLTg0YTE4ZmViYjQyZSIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjZmNjNmMzY1LTM5MmUtZjM0Yy1hNzZjLTg0YTE4ZmViYjQyZSI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NmY2M2YzNjUtMzkyZS1mMzRjLWE3NmMtODRhMThmZWJiNDJlIiBzdEV2dDp3aGVuPSIyMDIwLTA3LTA2VDExOjE5OjM4KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PgEk4u4AAARfSURBVGiB7Zndi1VVGMZ/zz57POqkiR8FomVBIYVZ4UWOVGSFaF0EgRgVREQ04QeSB0GCPnAUSbuJLoKgqIsI+gO6C7yIwOiqiyCowAiDBClw5riP6+lin31mz7TPxx73GafBB/bF3mu9H89ea73vu9aSbRYDouvtQFVYNETUaDSKGyRsY5soimg2m4QQOu22qdfr1Go1QghI6sjk+mwCboui6LztXzM5gCiKOnriOKZer3faQghMTk4iibxM9l6EykckZ3SdpP2SPrF9ELi1alt5xEPSeztwDHgeWA68CqwEJoBfhmFwGES22G4AzwCj7W/Lgb3AMuA08EPVRqsmsk3SUdtPA0tntd0EPEtK7hTwbZWGKyNie0zSm8DjkpZ06bZE0m5g1PaEpG+qsl/VYt8p6aTtJ4BuJDKMAI8CJ4E9FdkffESyUFyApyS9A2wtoS8Gttk+Rbp+voLp8NorzPZSOBDycT6KIqampiCNSkeBeyk/urW23ASwxvZHzWYToJOXSinbsWNHYUNeUZbsMhJRFMWSDkRR1AA2z4FERzUpia22lwHnQgitbvVfL3KlF7uk1SGEw5JeAjaUlS+C7Y2tVutQFEVrgPeAC2V1lCVyp+3Dtp8D1pQ11ge3hBBeBlYA7wM/lREuQ2SL7TdIE93NZYyUwCpgH9Nkzg0qOOjcfhA4LmkvwyORYQXpz5oAihdwAQYhst32adu7SUuM+cBSYCdpObNrEIF+RPZIOgM8RprI5hM14CHSxLmvX+cZRGaFvReBE8D2Cp2bCx6Q9DYwnn0oCs+1sbExII3R9XqdEIKAA0ADuGdeXO2PtZLuA0YkfTcyMtJhkuWW2Pb0SxyvSJLkdWA/FeWICrEROALU4zj+IIRwKT8y+fC7IUmS12yPA6vn2clBsc72kVartRL4EPgta8iI3G37UJIkL5Du5BYyViZJMi5pFXCGduKMgV2SjgEP29ZcKs/rgFHbrwCbJZ0Avo8lHQLul/QH0Mp1XkZahtSug6OzcRW4CEzmvsXAFuAg8G4s6XPgY9vJLOFNwFtUX1PNBZeA4+TWRBsjtuvA7zHwxWypdjS4S1KDhUHksu2vgZ+7Tf3/ZPY2CQHrWRjTClI/1gPqtlfpldkDCwsdf4rIxL0aS+IK8A8w1X4vquMyZ5aSVrn9Diq6Ip/IoU2koquFK7bPAmdJo0sdyCsW0CSNho9IepJrIAIzycQV3o+MAueBL4E/Ka6WE9Iz4DuYPoW8JmRkqjxplCTbbpJOoWaXfk1JJh2hSmC78tP4WFLPn9Nur/zMeSgXPd1i/TDLn6HdWM12etg13LDuR4DhO5/HorlDvEFkoeEGkYWGRUOkX/jN9iP9CrIszg76Y/L9BtHdd1/UjYjaz0XSCvXqAI7FzNxT98Ik8DfpGUG/fU+t7UfmUyHxbkRqgG1/RnrH189YANYCPzLzAKMIrXa/T4G/6D+KEXCZlECtmy9dt47/Nyyaxb5oiPwLVKNm6L0KZksAAAAASUVORK5CYII="
						alt=""><span data-v-405e9a63="">Home</span></li>
                    <li data-v-405e9a63="" onclick="window.location.href='search'" class=""><img data-v-405e9a63=""
                        src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAGkUlEQVRoQ9Waf4jURRTA39tVEKS0rP6wOEQo+wWhf1gphF7+oEJLQkMjTcOSTEtvZvYspQ3Mznmze5baL5SshPIHUYpF/iCDfqBiBWGZUlpdBJmmKNyBt/Nijt1l9nvf7+5+b49bfbDsst83b95n582bmTeLUKMIIe4GgEmI2AAADYV3Zj4PAH8CQBsztyHi0c7Ozl2tra2/1dhlaHPsiVEhxCxEnAgAEwDghpg2DjDzZ4i4k4i+i9k2Uj0WiFLqUWZeCABuFGoSZs4h4joAWE9Ex2syBgBVgQghpiDiMy6Eau0wpP1/DubkyZPpbdu25XpqvyKIlHI6AGwt1wEifmWt3QsApwHgX2Y+jYgDEHEIM1+dnzcuDG8rY2dnMpmc09LS4sBiS1mQChC7EXFzv3799q5atervanpuamq6NZlMTmDmBQBwS0ibtkQiMXb16tV/VGPP14kEEUK8iIjpEIPHmTljjHkrbmcF/XQ6PfjChQsCEZsAYEDQDjOPN8bsj2M/FCQKAhE3tre3L1u7du2pOJ1E6TY3N4+01q5h5ntqhekGopR6jplbQzpfSkRh39fMpJTaxMxzSkIFscNae1+1I1MCks9OO4KeEVHFpFArjZTSZcTPAzDHLl682Nja2vpXJfslDkopnaFgip1MRLsrGeqN50qpZcy8KgDzitb6+Ur2iyD5xW6z34CZs8YYNyH7TKSU+wCg0evwvLV2dCaTOVrOiSKIlPKbwIp9vKOjY2xvTexqf4mwEMuv/m5BjpQuECnlIwDwYWA0FtSSYqt1PExPSvkmADzlP7PWDstkMr9H2e0CEUKsR8SnPaXdRDS5FmdqaSulvBERv2bmawt2EHG21vr9siBSyhMAMMxrNE9r/U4tztTaVin1NjPP9+xsIqK5kSBSylEAcNhXyOVyDdls1p0l6iZKqceY+T3PgbNEdFUkSMgqfoiIRteNIN9xKpUaZK09G5i3kVsXlFJuBIB5hQbMnDbGvFRvkHwS+gIAxnm+PWSM+STMNweyJ3/S63rOzIuMMe7AU3eRUm4HgIc9R+YQkR9uxUeolPqFmW/yqGcaY0pScb2IQtLwYiJaGzoiSql2Zi5upa21kzKZjBuluotSaiUzv+A5soKIVkaF1j8AUMzXzDzVGLOz7hQAoJTKMPPSgi+IqLTWFAXiUq9LwQWZS0SbLgUQKaVbyx73wj5yt+Emu8sCUz3lJmNM9lIAEULsQMQpni+ziOiD0BEJbk+YeZ0xZtGlACKl/BEAbvd8eYCIPo0KLef0a14cHtNaj6g3SHNz8/BcLver74e19rZMJvNTVNYawcwle/1cLjcqm81+X08YKWXJDwwAR4jIH50S9wrbeEdZLM8g4hKt9Zp6ggghtiDiDM+HlUS0IsqnLhCl1KvMvNhT+nngwIFj0ul0yV6nr8CEEI2I6E6KRUHERq2127KESuE8MgMRt/gazPyyMWZ5Xznv9yOl3AUA93vfHSSiO8v5UjzqCiG+RES/vtSRTCbHtLS09OlcEUI8gYgbAk5H7rGKSarwQQgxDRE/Cgzndq21q/32iSilhjLzIQAY6nW4j4hc3bisBMtBbrPozu9+bC7SWvfJblhK6Wpq/gIIiDhNa/1xLBCl1F3M/G2wESI+qLXuVrirZDzO87AyLTO/boxx9zEVpVsFUQiRQsSWYEtm3mqMKRmtitarUHAVelfVR8SRAfX9RDS+ChNdKqGlUCmluw/pNjdc/CLi8t6qPLqJDQAGEQcHHD5FRNdVCxEJ4h5IKQ/kd8X9Qgy6K4VMT6/M8uuEq2D6KbbQzQkiGp73YToiXow9R4IOp1Kp+dbaNwAgGTJvTllrtwHA3kQisVdr7W5xIyWVSjVYa132ca+ZEYobiKirBCSl9M/rh621s6P2WWVHpNCRi+FEIuFCrdy1mVPfz8xnEPEMALiXk2sAYAgiDmPmO8qBImKxWC2EGIeIwVX8iLV2RuSmsZo4XLJkyfX9+/dfyMyu/npFNW1i6Oxzt7t++Cil7mVmdycZlEiYWPceTU1NNycSCQdTVUqsAHMwX5wOrYrk52hYfS0UJhZIwTF3Vujs7JyY/9OA++PAlVWOwA/MvCeRSOzRWpctcFQI6W4wPQIJOu1iGgAGIeIg955/dTDzuWQyeQ4AzjHzEa11W5XAXWpxYHoFJI5zcXWrhbnkQaodmcsCpBKMS92XDUhFmLgxW2/9sDnjbhAuqxEJ7DaeBYAnAcD92eDd/wHzROCR7+HNuQAAAABJRU5ErkJggg=="
                        alt=""><span data-v-405e9a63="">Search</span></li>
			
				<li data-v-405e9a63="" onclick="window.location.href='win'" class=""><img data-v-405e9a63=""
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAADF0lEQVRoQ+1aO2gUURQ9Nx8mYCfYiR+w0EbsTMD4qyVqwA/aGBG7FUdm3jYBYxOYeS+OmE6IBoL4Az9gk8L4BbVSUlkIiXY2dkKEZK9MSGR8O7PzdXeKmXLn3nvOub/d91hCwse2bU5oWqiZlJKSBExk5AeqhCRJZwubqiJRySl9a3WKYM6Oa3KnSkjRKc0Zr6pIzgQW7h5akbDd3alZSsqlElJ4b0QETFORTwD2BON0dXVtdRzne/CzsrRWvV7f0mg0vmm6P/utdQfAOU3IoOM470oqZF+j0XirCZn2hQgAjvbikZTyZBmF2Lb9EMAJjW+dhBBDzPxMb1EiOu+6rl+t1acMrSWEGGHm2yFcj66eRyzLek1E+zWDX8x8RCn1qgxCLMs6SETPAWwI8mTmN0qpA+tCjhPR45DFsUBEV1zXfdrJigghjjHzdQDbdY7MPKyUevL3hGjb9n0ApyK2oD9cg+1auRpOK+wHUsrTvv1fIUKIfmZ+3yGymWCJaMB13Q//CFmblb1EdAvA7kyR2+c0z8wXlVIf1yGbLh9M09zY09NzE8DZ9vFKhXR3eXn5kud5P4NekbcolmVdBXA4ZJulQi3K2N9OAOaUUtfCYsZeB5mmuaO7u/vQmqjVwWrXw8z+AppbWVl56Xne11a4sUKCzrZtLwDY1iYhi1LKpnUbhZ1KSNQ36/8Qpv+yiMNIJaRWqxl9fX1f2lCVxaWlpZ2Tk5O/4wREbq04R38JENFYnF2e98w8FjXUhbTWehAhhMfMl/OQjSREdMN1XTNt7FStpQ1+0zkmLXiI/bSUciRLnMxCfLCwQ1kWEr4PM08ppS5k9c8lxAe1LOsMEY0C2JWFBDPPMrM3MTExm8U/87CHgdVqtU2GYYwS0TCAzQkJvWDme0qpqYT2Lc1yVyQY3V/PhmEMEFE/gAEAQxr6PICZ3t7emfHx8R9FCCi0ImGEwtZ0lrWaVGyhFQmCVkKSlkCzqyoSl7iqteIyFPG+aq24xFWtFZehqrVaZKjoa9Skf9cIo5Rr2CshEVWuKhK8xM6yLMrUWn8AMZSO49QGBtUAAAAASUVORK5CYII="
						alt=""><span data-v-405e9a63="">Win</span></li>
				<li data-v-405e9a63="" onclick="window.location.href='me'"  class="active"><img data-v-405e9a63=""
						src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAYAAAAeP4ixAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFEmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDIgNzkuMTYwOTI0LCAyMDE3LzA3LzEzLTAxOjA2OjM5ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMC0wNy0wNlQxMToyMDoxOSswODowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjAtMDctMDZUMTE6MzM6MDYrMDg6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjAtMDctMDZUMTE6MzM6MDYrMDg6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6YzI0MGRmNzQtY2FmMy00MjQxLWFiYTYtYWQ5MjdmM2VlNzczIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOmMyNDBkZjc0LWNhZjMtNDI0MS1hYmE2LWFkOTI3ZjNlZTc3MyIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOmMyNDBkZjc0LWNhZjMtNDI0MS1hYmE2LWFkOTI3ZjNlZTc3MyI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6YzI0MGRmNzQtY2FmMy00MjQxLWFiYTYtYWQ5MjdmM2VlNzczIiBzdEV2dDp3aGVuPSIyMDIwLTA3LTA2VDExOjIwOjE5KzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PrrP240AAAXUSURBVGiBzdpdiF1XFQfw3zr33sw0M2kySS1NozUxhkhbta0l2FJFK1JFKtoYQWqx4hf4UEVQwbc8ib4VH/yIUEN9UUQfqg8K5kXaaGmpqJRSbBRpasWSTtM0k5l771k+nJl8zNxz5547M6Z/2My5++y19vqfvfdae689kZmWIw4fXlF3Ccpkc5uZTvU8Oc98Bx0i6JVEUgQvz4fX+mGqlWYmUrnYXyRlMNlnusvsJP0+V+5kcitlf6gJeejQJb/bwy0eC9fiA7hR5m5T7R0m220tPZkv4Z/4G47hhfXqdH2IRBL26TsoygMir8cuaVqnxSYkqtF/FSdl3EP8SfiFIp9bqwnrQWRCr3WbjPtl3kcWl7zNrEhcwBa8bbF8VD/2m2sfxR8xP64RxepNhmIbDprf9GNl8RmRzfRFtiwUn3V64oj0cWwd15A1EMkOPizjB8LesdUEinKf9H18CJ1x1AyeWuVKT7bifbpVxmFyyzgdr0Dapu+wLP6haD3eVHwwkZnNQ0QC/b1a+TmZ+5p2OBRFsd/c7OedO/OSXv+EGF10MJHNE0NEAt2PyO7HlI3MXB0RdM/eo9v/q4Xye00m/mAi/d6w3rZR3okdTWwcGUWxQzvuJB8WZkcVG0wkhxHxfmGPJuPeBIkidpvwHjwyqtjgwSuGlHADdq3R3NWwS+lGJbVlGQaPyKmFweoz2dJ5q4nWzKqebW3Yroi9itFHfTCRue7g1mXJVPsaaw+kwxHR0iuvdbY78gweTGTL9BCJvMKAHfO6ItDLKa92K082AgYT2VHnkILebFe5YMMW+4WuuopYI5F+3VkgyHxlTNMaIl5edC4joYbI7BCRPEnMY1jUXBvKnNOJk3ZMjixSE0eGns6eFsWLeHMj45rhReFp7dF9yuCWUQwrx3BinQyuwwn8vjrL1JRlGEykVQwrzyriuDC3MRxyjjxOPrd4rKwpoxAZFlFLZPxaxmPrTwKlPyjjNzIMLcsweI2cWdVVPK7tIZN5h1zHRR95Tr/zkF7rcdEsVo0XoVNf+K0ivjuqnx8JZXxHxu/IxgeEtSQfXsKPlDZJX1LYNr6q8pRs/ZA4glPjaKhxv6tIXVhzzyt9W6f3b1kcksXtmoX8JB5Vdn5OHhVOV7VRY0S96sFEWhcruVg4L/y5MClfMdF90HznCWXrAeEmcjumMcliOijO6zqHM8Ip8ill60H9yeNac4u8klZZY/dgj1VP5IqlgHjRXqdUdVI9VDFlSWflRR6VxaPELfTuFm6R9otipyI6ZFfmC+SzeFIrHpHxlP6S3kU97Z7zzM8TWXooGxIZFaEavfmJi766v+Dv2KTsd2zb2bF5pnB2tvTKC11F0cUCzhIUfYpzi0TqDV0N65MyXfLrUUKPxbleFMydpnuO/kI1iktft895oyMHxoYmWCuRGezFW7CVnMaUKtu7lBVh4UyKIioioCudxWv4L57FvzD2znpcIm/CO6Tb8U68HW/AFStaLu3RBqOL5/Ek+Ywq//uMaq/VaI41JTKFm/FJmZ/CVQ3ll6ODPTL3VD/zVfwKP8ETqsz9SGgS2Vs4RHGU+LKNyGtFTIu4l3gYX2gi2oTIQXxLtR5aNuasG2gJu4Rv4siogqtPrTQl3CvyAaxvrnc4rsanVTZ+xZInrMFqIzKFT+AbuGE9rGuISdyPL+LKYQ1XI/JufFXm+Pcf64Ovqz5obZ5qGJE27sZN62vTOMirya/hg2psHnZmP4B3jbtl2ADsx324btDLwUSqA/77cP2GmdUcbeK9xMHl963UE5nGHdi+sbY1xg7iLmLFpWnNGombWcMF58Zit3Dr8so6Irdh2EXi5cRm4cDyyhoi5S6VD389YkJZXrO8ss5rbTfmfff/AZ1F+y5BXRy5zut5ROQbl1fWTa2TG23NGjDBytvewZvGKH4pc7fqwNRx+aNiqP7h5jSeEfGz5Q1qdr+d47L7U/Iu4SpVsuByoi3zP/izcIyVeef/AcX23Hm25eOYAAAAAElFTkSuQmCC"
						alt=""><span data-v-405e9a63="">My</span></li>
			</ul>
		</div>
       
        <div data-v-1f39f91d="" class="notice_zz" id="notice" style="display: none;">
            <div data-v-1f39f91d="" class="wrapper" style="max-height: 70vh;">
                <p data-v-1f39f91d="" class="tz_title">Notice</p>
                <p data-v-1f39f91d="" class="tz_info"><?php echo $notice?></p>
                <div data-v-1f39f91d="" class="tz_close"><button data-v-1f39f91d="" id="x">CLOSE</button></div>
            </div>
        </div>
        <div data-v-1f39f91d="" class="notice_zz" id="box" style="display: none;"><div data-v-1f39f91d="" class="wrapper"><p data-v-1f39f91d="" class="tz_title">Sign In</p><div data-v-1f39f91d="" class="signinInfo"><p data-v-1f39f91d="" class="signinfo" id="days">Total：0 Days</p><p data-v-1f39f91d="" class="signinfo">Today Rebates：₹ 0</p><p data-v-1f39f91d="" class="signinfo">Total Rebates：₹ 0</p><p data-v-1f39f91d="" class="signinfo" id="status">
            Status：Not signed in
          </p><!----></div><div data-v-1f39f91d="" class="tz_close"><button data-v-1f39f91d="" style="color: rgb(136, 136, 136);" id="boxclose">CANCEL</button><button data-v-1f39f91d="" onclick="sign()">SIGN IN</button></div></div></div>
      
        <div data-v-1f39f91d="" id="logout" class="notice_zz" style="display: none;">
            <div data-v-1f39f91d="" class="wrapper">
                <p data-v-1f39f91d="" class="tz_title">Confirm</p>
                <p data-v-1f39f91d="" class="tz_info">Do you want to logout?</p>
                <div data-v-1f39f91d="" class="tz_close"><button data-v-1f39f91d="" id="close"
                        style="color: rgb(136, 136, 136);">CANCEL</button><button id="confirm" data-v-1f39f91d="">YES</button></div>
            </div>
        </div>


    </div>
    <script src="js/chunk-vendors.824d6eef.js"></script>
    <script src="js/me.js"></script>
    <script >
     
    document.getElementById("wallet").onclick = function () { 
         if( document.getElementById("walletdrop").style.display = "none")
        {
            document.getElementById("walletdrop").style.display = "";
            setTimeout(function () {   document.getElementById("walletdrop").style.display = "none"; }, 2000);
}
            

        }
        
    document.getElementById("icon").onclick = function () {
        document.getElementById("notice").style.display = "";
    }
    document.getElementById("x").onclick = function () {
        document.getElementById("notice").style.display = "none";
    }
        document.getElementById("signin").onclick = function () {
        document.getElementById("box").style.display = "";
    }
    document.getElementById("boxclose").onclick = function () {
        document.getElementById("box").style.display = "none";
    }
      function sign(){
           document.getElementById("days").innerHTML="Total：1 Days";
            document.getElementById("status").innerHTML="Status:Had signed in";
      }
      
      
       
    
      </script>
    </script>
       
      <script>
                
   

 
    
  

    
   
    </script>
       
      </body>

</html>