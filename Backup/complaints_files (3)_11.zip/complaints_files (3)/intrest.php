<?php


define('DB_SERVER', '68.178.145.3');
define('DB_USERNAME', 'red-bu13');
define('DB_PASSWORD', '38^3O{d%vXqQ');
define('DB_NAME', 'red-bu13');

// Try connecting to the Database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

//Check the connection
if($conn == false){
    dir('Error: Cannot connect');
}
  

$sql3 = "SELECT * FROM users WHERE balance!='0'";
$result3 =$conn->query($sql3);

//display the retrieved result on the webpage  
while ($row3 = mysqli_fetch_array($result3)) {  
$user=$row3['username'];
$balance=$row3['balance'];
$intrest=(2/100*$balance);
    $addwin0="UPDATE users SET balance= balance +($intrest/2) WHERE username=$user ";
    $conn->query($addwin0);
$rec="INSERT INTO intrest (username,amount) VALUES ($user,$intrest)";
$conn->query($rec);
    
}


?>